"use strict";

const SCHEMA = [
  ["category","Broad event category.","classification"],["subcategory","Granular event category.","classification"],["entity","Principal named entity.","entities"],["primary_event","Primary event described by the record.","event_chain"],["event_type","Normalised event type.","classification"],["commodity_attributes","Commodities affected by the event.","physical_market"],["country_attributes","Countries associated with the event.","geography"],["duration_attributes","Stated or expected event duration.","timing"],["quantity_attributes","Physical quantities reported in the event.","physical_market"],["financial_attributes","Financial measures and impacts.","market_context"],["forecast_attributes","Forward-looking statements or estimates.","expectations"],["group_attributes","Organisations, alliances, or other groups.","entities"],["location_attributes","Facilities, regions, routes, and locations.","geography"],["money_attributes","Currency-denominated amounts.","market_context"],["production_unit_attributes","Production-rate or capacity units.","physical_market"],["state_or_province","Subnational geographic location.","geography"],["percent_attributes","Percentage values stated in the event.","market_context"],["person_attributes","People associated with the event.","entities"],["price_unit_attributes","Price units and quote conventions.","market_context"],["event_trigger","Immediate trigger or initiating development.","causality"],["related_entity","Secondary entity connected to the primary event.","entities"],["second_event","Second event in the narrative chain.","event_chain"],["third_event","Third event in the narrative chain.","event_chain"],["outcome","Reported or expected event outcome.","outcomes"],["outcome_attribute","Structured properties of the outcome.","outcomes"],["temporal_attribute","Temporal ordering, dates, or timing language.","timing"],["polarity","Directional polarity of the event.","expectations"],["modality","Certainty, possibility, or obligation expressed in the event.","expectations"],["causal_links","Extracted cause-and-effect relationships.","causality"],["influencing_factors","Other factors influencing the event or outcome.","causality"]
];

const palette={Supply:"#61e8d0",Demand:"#65bffb",Policy:"#a68cff",Geopolitics:"#ff7b8d",Macro:"#ffc878",Operations:"#70d9a5"};
const polarityColors={Negative:"#ff7b8d",Neutral:"#ffc878",Positive:"#61e8d0"};
let allPoints=[];

function mulberry32(seed){return function(){let t=seed+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
function normal(rand){return(Math.sqrt(-2*Math.log(Math.max(rand(),1e-8)))*Math.cos(2*Math.PI*rand()))}
function syntheticPoints(){
  const rand=mulberry32(240519);const groups=[
    ["Supply","Production disruption",[-2.1,.5,.9],"Negative"],["Demand","Consumption outlook",[1.6,-1,.5],"Neutral"],["Policy","Production decision",[.5,1.8,-1],"Neutral"],["Geopolitics","Conflict escalation",[-.9,-1.8,-1.1],"Negative"],["Macro","Economic indicator",[2,1.2,.8],"Positive"],["Operations","Facility restart",[-1.7,.2,-1.7],"Positive"]
  ];const out=[];
  groups.forEach((g,gi)=>{for(let i=0;i<58;i++){const polarity=i%7===0?"Neutral":i%9===0?"Positive":g[3];out.push({event_id:`DEMO-${String(gi*58+i+1).padStart(4,"0")}`,date:`202${1+gi%5}-${String(1+(i*3)%12).padStart(2,"0")}-${String(1+(i*7)%27).padStart(2,"0")}`,category:g[0],subcategory:g[1],event_type:g[1],polarity,x:g[2][0]+normal(rand)*.48,y:g[2][1]+normal(rand)*.48,z:g[2][2]+normal(rand)*.48,dataset:"synthetic_demo"})}});return out;
}

function titleCase(value){return String(value||"").replaceAll("_"," ").replace(/\b\w/g,c=>c.toUpperCase())}
function unique(key){return[...new Set(allPoints.map(p=>p[key]).filter(Boolean))].sort()}
function fillFilter(id,key){const select=document.getElementById(id);unique(key).forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;select.append(o)})}
function filteredPoints(){const q=document.getElementById("atlas-search").value.trim().toLowerCase();const c=document.getElementById("category-filter").value;const p=document.getElementById("polarity-filter").value;return allPoints.filter(v=>(c==="all"||v.category===c)&&(p==="all"||v.polarity===p)&&(!q||[v.event_id,v.category,v.subcategory,v.event_type,v.polarity].join(" ").toLowerCase().includes(q)))}

function plot(points,resetCamera=false){
  const summary=document.getElementById("atlas-summary");summary.textContent=`Showing ${points.length.toLocaleString()} of ${allPoints.length.toLocaleString()} events`;
  if(!window.Plotly){document.getElementById("embedding-plot").innerHTML='<p class="plot-fallback">The 3D library could not load. Check your network connection.</p>';return}
  const traces=unique("category").map(category=>{const rows=points.filter(p=>p.category===category);return{type:"scatter3d",mode:"markers",name:category,x:rows.map(p=>p.x),y:rows.map(p=>p.y),z:rows.map(p=>p.z),customdata:rows,marker:{size:4.5,color:palette[category]||"#94a9bd",opacity:.78,line:{width:.15,color:"#ffffff"}},hovertemplate:"<b>%{customdata.event_id}</b><br>%{customdata.category} · %{customdata.event_type}<br>%{customdata.date}<extra></extra>"}});
  const layout={paper_bgcolor:"rgba(0,0,0,0)",plot_bgcolor:"rgba(0,0,0,0)",margin:{l:0,r:0,t:0,b:0},showlegend:false,scene:{bgcolor:"rgba(0,0,0,0)",aspectmode:"cube",xaxis:axis("Dimension 1"),yaxis:axis("Dimension 2"),zaxis:axis("Dimension 3"),camera:{eye:{x:1.55,y:1.55,z:1.25}}},font:{family:"Inter, sans-serif",color:"#91a5bc"},uirevision:resetCamera?String(Date.now()):"keep"};
  Plotly.react("embedding-plot",traces,layout,{responsive:true,displaylogo:false,modeBarButtonsToRemove:["toImage","sendDataToCloud","lasso3d","select2d"]});
  const el=document.getElementById("embedding-plot");el.removeAllListeners?.("plotly_click");el.on?.("plotly_click",e=>inspect(e.points[0].customdata));
}
function axis(title){return{title:{text:title,font:{size:10,color:"#72889e"}},gridcolor:"rgba(145,165,188,.12)",zerolinecolor:"rgba(97,232,208,.22)",tickfont:{size:8,color:"#587086"},showbackground:false}}
function inspect(p){document.getElementById("point-inspector").innerHTML=`<p class="inspector-kicker">Selected event</p><h3>${escapeHtml(p.event_id)}</h3><dl><dt>Date</dt><dd>${escapeHtml(p.date||"—")}</dd><dt>Category</dt><dd>${escapeHtml(p.category||"—")}</dd><dt>Type</dt><dd>${escapeHtml(p.event_type||p.subcategory||"—")}</dd><dt>Polarity</dt><dd style="color:${polarityColors[p.polarity]||"inherit"}">${escapeHtml(p.polarity||"—")}</dd></dl>`}
function escapeHtml(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}

async function loadAtlas(){
  let meta={sample_data:true};try{const response=await fetch("./data/embeddings_3d.json",{cache:"no-store"});if(!response.ok)throw new Error(String(response.status));meta=await response.json();if(!Array.isArray(meta.points)||!meta.points.length)throw new Error("empty export");allPoints=meta.points}catch(_){allPoints=syntheticPoints()}
  const badge=document.getElementById("data-badge");if(meta.sample_data===false){badge.className="data-badge real";badge.innerHTML="<i></i> Approved repository projection"}else{badge.className="data-badge demo";badge.innerHTML="<i></i> Synthetic demonstration"}
  fillFilter("category-filter","category");fillFilter("polarity-filter","polarity");plot(allPoints,true);
  ["atlas-search","category-filter","polarity-filter"].forEach(id=>document.getElementById(id).addEventListener(id==="atlas-search"?"input":"change",()=>plot(filteredPoints())));
  document.getElementById("reset-view").addEventListener("click",()=>{document.getElementById("atlas-search").value="";document.getElementById("category-filter").value="all";document.getElementById("polarity-filter").value="all";plot(allPoints,true)});
}

function renderSchema(){
  const grid=document.getElementById("schema-grid"),search=document.getElementById("schema-search"),chips=document.getElementById("schema-groups");let group="all";
  const groups=["all",...new Set(SCHEMA.map(x=>x[2]))];groups.forEach((g,i)=>{const b=document.createElement("button");b.type="button";b.className=`chip${i===0?" active":""}`;b.textContent=titleCase(g);b.dataset.group=g;b.addEventListener("click",()=>{group=g;chips.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));draw()});chips.append(b)});
  function draw(){const q=search.value.toLowerCase();const rows=SCHEMA.filter(x=>(group==="all"||x[2]===group)&&(!q||x.join(" ").toLowerCase().includes(q)));grid.innerHTML=rows.map(x=>`<article class="field-card"><header><code>${x[0]}</code><span class="group-tag">${titleCase(x[2])}</span></header><p>${x[1]}</p></article>`).join("");document.getElementById("schema-count").textContent=`${rows.length} of ${SCHEMA.length} attributes`}
  search.addEventListener("input",draw);draw();
}

document.getElementById("copy-code").addEventListener("click",async e=>{try{await navigator.clipboard.writeText(document.getElementById("curl-code").innerText);e.currentTarget.textContent="Copied";setTimeout(()=>e.currentTarget.textContent="Copy",1400)}catch(_){e.currentTarget.textContent="Select + copy"}});
renderSchema();loadAtlas();
