# Brahmanda GitHub Pages site

This directory is a static public-facing introduction to the Event Intelligence Framework. It includes an interactive Plotly 3D embedding atlas, the exact 30-field public metadata contract, the deployment boundary, and API examples.

## Preview locally

From the repository's `brahmanda` directory:

```bash
python -m http.server 8080 --directory docs
```

Open `http://127.0.0.1:8080`.

## Export approved repository coordinates

The website uses a clearly labelled synthetic demonstration unless an approved export exists. To generate the public projection from a metadata file that already contains `dim1`, `dim2`, and `dim3`:

```bash
python scripts/export_public_site_data.py \
  --metadata memory_2024_2026/df_major_metadata_2024_2026.csv \
  --output docs/data/embeddings_3d.json \
  --max-points 3000
```

Review the generated JSON before committing it. The exporter writes only `event_id`, `date`, `category`, `subcategory`, `event_type`, `polarity`, `x`, `y`, `z`, and `dataset`. It will not export source text, document IDs, embeddings, or vendor content.

## Publish after approval

1. Commit this `docs/` directory to a reviewed feature branch.
2. Merge the feature branch into the repository's default branch.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the default branch and the `/docs` folder, then save.

After GitHub finishes its Pages workflow, the expected address is:

`https://dbalaji111.github.io/Event_Intelligence_Framework/`

Do not place credentials or private endpoints in this static site. A browser-delivered secret is not a secret.
